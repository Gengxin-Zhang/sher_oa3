class ProductionConfig():
    Debug = False
    MONGODB_SETTINGS = {
        'db': 'sheroa3',
        'host': 'mongodb://mongodb/sheroa3',
    }