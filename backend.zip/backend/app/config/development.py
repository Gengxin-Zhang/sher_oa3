class DevelopmentConfig():
    Debug = True
    