def trueReturn(data, msg):
    return {
        'data': data,
        'msg': msg,
        'status': True
    }

def falseReturn(data, msg):
    return {
        'data': data,
        'msg': msg,
        'status': False
    }